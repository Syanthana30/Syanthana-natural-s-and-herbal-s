<h1>Hairvanà </h1>

<div class="product">
    <img id="product-image" src="placeholder.jpg" alt="Hairvana Oil"> <input type="filw" id="image-upload" accept="image/*"> <label for="image-upload">Upload Image</label>
    <h2>Hairvana Oil bo5tel capacity </h2>
    <div class="sizes">
      <label><input type="radio" name="size" value="10000">we are currently available with current options 
     </div>
          <div class="sizes>
       <label><input type="radio" name="size" value="1000"> 1. 1 Litre</label>
          </div>
    <div class="sizes>
        <label><input type="radio" name="size" value="500"> 2. 500 ml</label>
        </div>
    </div>
          <label><input type="radio" name="size" value="200"> 3. 200 ml</label>
      </div>
        <div class="sizes>
        <label><input type="radio" name="size" value="100"> 4. 100 ml</label>
        </div>
      </div>
<div class="contact-info">
  <h2>Contact Us</h2>
  <p>Phone: 9494952109</p>
</div>


   we are available in whatsapp Instagram 
  for order purpose please contact for above number 

